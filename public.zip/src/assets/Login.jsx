import React, { useState } from 'react';

function Login() {
    const [isSignup, setIsSignup] = useState(false);

    const toggleForm = () => {
        setIsSignup(!isSignup);
    };

    return (
        <div className="d-flex justify-content-center align-items-center vh-100">
            <div className="text-center">
                <h1>{isSignup ? "Signup" : "Login"}</h1>
                {isSignup ? <SignupForm /> : <LoginForm />}
                <button className="btn btn-warning mt-3" onClick={toggleForm}>
                    {isSignup ? "Switch to Login" : "Switch to Signup"}
                </button>
            </div>
        </div>
    );
}

function LoginForm() {
    return (
        <div className='d-flex justify-content-center align-items-center border border-primary rounded p-5 w-100'>
            <center>
                <form >
                    <div >
                        <img src="https://img.freepik.com/free-vector/instagram-icon_1057-2227.jpg?size=626&ext=jpg&ga=GA1.2.180599784.1691488875&semt=ais" alt="" style={{ width: '80px' }} />
                    </div>
                    <table>
                        <tr>
                            <td><label>UserName: </label></td>
                            <td><input className='form-control' type="text" /></td>
                        </tr><br />
                        <tr>
                            <td><label htmlFor="">Password: </label></td>
                            <td> <input className='form-control' type="password" /></td>
                        </tr><br />
                        <tr><td></td>
                            <td><button className='btn btn-success' type="submit">Login</button></td>
                        </tr>
                    </table>

                </form>
            </center>
        </div>

    );
}

function SignupForm() {
    return (
        <>
            <div className='d-flex justify-content-center align-items-center border border-primary rounded p-5 w-100'>
                <form>
                    <div >
                        <img src="https://img.freepik.com/free-vector/instagram-icon_1057-2227.jpg?size=626&ext=jpg&ga=GA1.2.180599784.1691488875&semt=ais" alt="" style={{ width: '80px' }} />
                    </div>
                    <table>
                        <tr>
                            <td> <label >Full Name:</label></td>
                            <td><input type="text" className='form-control' /></td>
                        </tr>
                        <tr>
                            <td> <label >Email:</label></td>
                            <td><input type="email" className='form-control' /></td>
                        </tr>
                        <tr>
                            <td> <label >Password:</label></td>
                            <td><input type="password" className='form-control' /></td>
                        </tr>
                        <tr>
                            <td> <label >Confirm Password:</label></td>
                            <td><input type="password" className='form-control' /></td>
                        </tr>
                        <tr>
                            <td> <label >DOB.:</label></td>
                            <td><input type="date" className='form-control' /></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><button className='btn btn-primary'>Register</button></td>
                        </tr>
                    </table>

                </form>

            </div>

        </>

    );
}

export default Login;
