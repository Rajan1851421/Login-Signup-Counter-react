import React, { useState } from 'react';
import { Link } from 'react-router-dom'

function Counter() {
    const [count, setCount] = useState(0);

    return (
        <>
            <div className='d-flex justify-content-center align-items-center mt-5'>
                <div className="border p-5 rounded w-75 bg-danger">
                   
                    <div className="row">
                        <div className="col">
                        <h3 className='text-dark'>{count}</h3>
                            <div className='d-flex justify-content-center'>
                                <button className='btn btn-warning' onClick={() => setCount((count) => count + 1)}>Increment</button>
                                <button className='btn btn-primary' onClick={() => setCount((count) => Math.max(count - 1, 0))} disabled={count === 0} style={{ marginLeft: '10px' }}  >Decrement</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Counter;
