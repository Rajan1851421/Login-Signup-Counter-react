import './App.css'
import Counter from './assets/Counter'
import Login from './assets/Login'
import{Route,Routes}from "react-router-dom";
import Navbar from './assets/Navbar';

function App() {
 

  return (
    <>
    <Navbar/>     
     
      <Routes>
        <Route path="/login" element={<Login/>}/>
        <Route path='/counter' element={<Counter/>}/>    
      </Routes>
     
    </>
  )
}

export default App
